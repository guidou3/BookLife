#include "bookwidget.h"

BookWidget::BookWidget(Book* lib, QWidget *parent) : QWidget(parent), libro(lib)
{
    if(libro == NULL)
    {
        cerr << "Libro non fornito" << endl;
        return;
    }
    mainLayout = new QVBoxLayout;
    centralLayout = new QHBoxLayout;
    visualizzaBox = new QGroupBox;

    QVBoxLayout* dxlo = new QVBoxLayout;

    titoloLabel = new QLabel;
    dataPubblicazioneLabel = new QLabel;
    linguaLabel = new QLabel;
    descrizioneLabel = new QLabel;
    immagineLabel = new QLabel;
    numeroPagineLabel = new QLabel;
    editoreLabel = new QLabel;
    collanaLabel = new QLabel;

    autoriList = new QListWidget;
    generiList = new QListWidget;
    curatoriList = new QListWidget;

    titoloLabel->setText(libro->getTitolo());
    dataPubblicazioneLabel->setText(libro->getDataPubblicazione().toString());
    linguaLabel->setText(libro->getLingua());
    descrizioneLabel->setText(libro->getDescrizione());
    descrizioneLabel->setWordWrap(true);
    numeroPagineLabel->setText(QString::number(libro->getNumeroPagine()));
    editoreLabel->setText(libro->getEditore());
    collanaLabel->setText(libro->getCollana());

    autoriList->addItems(libro->getAutori());
    autoriList->setMaximumHeight(100);
    generiList->addItems(libro->getGeneri());
    generiList->setMaximumHeight(100);
    curatoriList->addItems(libro->getCuratori());
    curatoriList->setMaximumHeight(100);

    if(!libro->getImmagine().isEmpty())
    {
        QPixmap pix(libro->getImmagine());
        immagineLabel->setPixmap(pix.scaled(300, 450, Qt::KeepAspectRatio));
    }
    else
    {
        immagineLabel->hide();
    }

    QFormLayout* flayout = new QFormLayout;

    flayout->addRow("Titolo: ", titoloLabel);
    flayout->addRow("Data di pubblicazione: ", dataPubblicazioneLabel);
    flayout->addRow("Lingua: ", linguaLabel);
    flayout->addRow("Descrizione: ", descrizioneLabel);
    flayout->addRow("Numero pagine: ", numeroPagineLabel);
    flayout->addRow("Editore: ", editoreLabel);
    flayout->addRow("Collana: ", collanaLabel);
    flayout->addRow("Autori: ", autoriList);
    flayout->addRow("Generi: ", generiList);
    flayout->addRow("Curatori: ", curatoriList);

    dxlo->addWidget(immagineLabel);
    dxlo->setAlignment(immagineLabel, Qt::AlignTop);

    if(!libro->getLibro().isEmpty())
    {
        linkToPdf = new QPushButton;
        linkToPdf->setText("Leggi");
        linkToPdf->setMinimumHeight(50);
        linkToPdf->setMinimumWidth(100);
        connect(linkToPdf,SIGNAL(clicked()),this,SLOT(visualizzaPdfSlot()));
        dxlo->addWidget(linkToPdf);
    }
    visualizzaBox->setLayout(flayout);
    visualizzaBox->setTitle("Informazioni sul libro");
    centralLayout->addWidget(visualizzaBox);
    centralLayout->addLayout(dxlo);
    mainLayout->addLayout(centralLayout);
    setLayout(mainLayout);
}

BookWidget::BookWidget(Book* lib, Client* c, QWidget *parent) : QWidget(parent), libro(lib), logic(c)
{
    if(libro == NULL)
    {
        cerr << "Libro non fornito" << endl;
        return;
    }

    initialize();

    titoloSchedaLabel->setText("Modifica informazioni del Book");

    titoloEdit->setText(libro->getTitolo());
    titoloEdit->setEnabled(false);
    dataPubblicazioneEdit->setDate(libro->getDataPubblicazione());
    linguaEdit->setText(libro->getLingua());
    descrizioneEdit->setText(libro->getDescrizione());
    numeroPagineEdit->setText(QString::number(libro->getNumeroPagine()));
    editoreEdit->setText(libro->getEditore());
    collanaEdit->setText(libro->getCollana());

    fileImmagine->setText(libro->getImmagine());
    if(fileImmagine->text().isEmpty()) fileImmagine->setText("NULL");
    fileLibro->setText(libro->getLibro());
    if(fileLibro->text().isEmpty()) fileLibro->setText("NULL");

    autoriList->addItems(libro->getAutori());
    autoriList->setMaximumHeight(100);
    generiList->addItems(libro->getGeneri());
    generiList->setMaximumHeight(100);
    curatoriList->addItems(libro->getCuratori());
    curatoriList->setMaximumHeight(100);

    connect(salva,SIGNAL(clicked()),this,SLOT(aggiornaSlot()));
}

BookWidget::BookWidget(Client* c, QWidget *parent) : QWidget(parent, Qt::Window), logic(c)
{
    libro = new Book("Titolo temporaneo");

    initialize();

    titoloSchedaLabel->setText("Crea un nuovo Book");

    titoloLabel = new QLabel;
    titoloLabel->hide();

    fileImmagine->setText("NULL");
    fileLibro->setText("NULL");

    autoriList->setMaximumHeight(100);
    generiList->setMaximumHeight(100);
    curatoriList->setMaximumHeight(100);

    connect(salva,SIGNAL(clicked()),this,SLOT(salvaSlot()));
}

BookWidget::~BookWidget()
{

}

void BookWidget::initialize()
{
    mainLayout = new QVBoxLayout;
    visualizzaBox = new QGroupBox;

    titoloEdit = new QLineEdit;
    dataPubblicazioneEdit = new QDateEdit;
    linguaEdit = new QLineEdit;
    descrizioneEdit = new QLineEdit;
    numeroPagineEdit = new QLineEdit;
    numeroPagineEdit->setValidator(new QIntValidator(0, 10000, this));
    editoreEdit = new QLineEdit;
    collanaEdit = new QLineEdit;
    autoreEdit = new QLineEdit;
    genereEdit = new QLineEdit;
    curatoreEdit = new QLineEdit;

    fileImmagine = new QLabel;
    fileLibro = new QLabel;

    autoriList = new QListWidget;
    generiList = new QListWidget;
    curatoriList = new QListWidget;

    addAutore = new QPushButton;
    removeAutore = new QPushButton;
    addGenere = new QPushButton;
    removeGenere = new QPushButton;
    addCuratore = new QPushButton;
    removeCuratore = new QPushButton;
    annulla = new QPushButton;
    salva = new QPushButton;
    QPushButton* addLibro = new QPushButton;
    QPushButton* addImmagine = new QPushButton;

    addAutore->setText("Inserisci");
    removeAutore->setText("Rimuovi");
    removeAutore->hide();
    addGenere->setText("Inserisci");
    removeGenere->setText("Rimuovi");
    removeGenere->hide();
    addCuratore->setText("Inserisci");
    removeCuratore->setText("Rimuovi");
    removeCuratore->hide();
    addLibro->setText("Aggiungi file");
    addImmagine->setText("Aggiungi immagine");
    annulla->setText("ANNULLA");
    annulla->setMaximumWidth(150);
    salva->setText("SALVA");
    salva->setMaximumWidth(150);

    connect(autoriList,SIGNAL(itemDoubleClicked(QListWidgetItem*)),this,SLOT(getAutoreSlot()));
    connect(generiList,SIGNAL(itemDoubleClicked(QListWidgetItem*)),this,SLOT(getGenereSlot()));
    connect(curatoriList,SIGNAL(itemDoubleClicked(QListWidgetItem*)),this,SLOT(getCuratoreSlot()));
    connect(addAutore,SIGNAL(clicked()),this,SLOT(aggiungiAutoreSlot()));
    connect(removeAutore,SIGNAL(clicked()),this,SLOT(rimuoviAutoreSlot()));
    connect(addGenere,SIGNAL(clicked()),this,SLOT(aggiungiGenereSlot()));
    connect(removeGenere,SIGNAL(clicked()),this,SLOT(rimuoviGenereSlot()));
    connect(addCuratore,SIGNAL(clicked()),this,SLOT(aggiungiCuratoreSlot()));
    connect(removeCuratore,SIGNAL(clicked()),this,SLOT(rimuoviCuratoreSlot()));
    connect(addLibro,SIGNAL(clicked()),this,SLOT(apriFile()));
    connect(addImmagine,SIGNAL(clicked()),this,SLOT(apriImmagine()));
    connect(annulla,SIGNAL(clicked()),this,SLOT(close()));

    QVBoxLayout* v1 = new QVBoxLayout;
    v1->addWidget(autoriList);
    v1->addWidget(removeAutore);

    QVBoxLayout* v2 = new QVBoxLayout;
    v2->addWidget(generiList);
    v2->addWidget(removeGenere);

    QVBoxLayout* v3 = new QVBoxLayout;
    v3->addWidget(curatoriList);
    v3->addWidget(removeCuratore);

    QHBoxLayout* h1 = new QHBoxLayout;
    h1->addWidget(autoreEdit);
    h1->addWidget(addAutore);

    QHBoxLayout* h2 = new QHBoxLayout;
    h2->addWidget(genereEdit);
    h2->addWidget(addGenere);

    QHBoxLayout* h3 = new QHBoxLayout;
    h3->addWidget(curatoreEdit);
    h3->addWidget(addCuratore);

    QFormLayout* flayout = new QFormLayout;

    flayout->addRow("Titolo: ", titoloEdit);
    flayout->addRow("Data di pubblicazione: ", dataPubblicazioneEdit);
    flayout->addRow("Lingua: ", linguaEdit);
    flayout->addRow("Descrizione: ", descrizioneEdit);
    flayout->addRow("Numero pagine: ", numeroPagineEdit);
    flayout->addRow("Editore: ", editoreEdit);
    flayout->addRow("Collana: ", collanaEdit);
    flayout->addRow("Autori: ", v1);
    flayout->addRow("Nuovo autore: ", h1);
    flayout->addRow("Generi: ", v2);
    flayout->addRow("Nuovo genere: ", h2);
    flayout->addRow("Curatori: ", v3);
    flayout->addRow("Nuovo curatore: ", h3);
    flayout->addRow("File selezionato : ", fileLibro);
    flayout->addRow("", addLibro);
    flayout->addRow("Immagine selezionata: ", fileImmagine);
    flayout->addRow("", addImmagine);

    QHBoxLayout* buttons = new QHBoxLayout;

    buttons->addWidget(annulla);
    buttons->addSpacing(50);
    buttons->addWidget(salva);

    visualizzaBox->setLayout(flayout);

    titoloSchedaLabel = new QLabel;
    QFont font = QFont("arial", 12, QFont::Bold);
    titoloSchedaLabel->setFont(font);

    QScrollArea* scroll = new QScrollArea;
    scroll->setWidget(visualizzaBox);
    scroll->adjustSize();
    scroll->setWidgetResizable(true);

    QVBoxLayout* mall = new QVBoxLayout;
    mall->addWidget(scroll);

    mainLayout->addWidget(titoloSchedaLabel);
    mainLayout->addLayout(mall);
    mainLayout->addLayout(buttons);
    setLayout(mainLayout);
}

void BookWidget::hide()
{
    if(!removeAutore->isHidden()) removeAutore->hide();
    if(!removeGenere->isHidden()) removeGenere->hide();
    if(!removeCuratore->isHidden()) removeCuratore->hide();
}

void BookWidget::salvaSlot()
{
    if(!titoloEdit->text().isEmpty() && !logic->getSession()->db->findBook(titoloEdit->text()) && !logic->getSession()->db->findLightNovel(titoloEdit->text()))
    {
        libro->setTitolo(titoloEdit->text());
        if(!dataPubblicazioneEdit->text().isEmpty()) libro->setDataPubblicazione(dataPubblicazioneEdit->date());
        if(!linguaEdit->text().isEmpty()) libro->setLingua(linguaEdit->text());
        if(!descrizioneEdit->text().isEmpty()) libro->setDescrizione(descrizioneEdit->text());
        if(!numeroPagineEdit->text().isEmpty()) libro->setNumeroPagine(numeroPagineEdit->text().toInt());
        if(!editoreEdit->text().isEmpty()) libro->setEditore(editoreEdit->text());
        if(!collanaEdit->text().isEmpty()) libro->setCollana(collanaEdit->text());
        if(fileLibro->text() != "NULL")
        {
            libro->setLibro(libro->getTitolo() + ".pdf");
            QFile::copy(fileLibro->text(), libro->getLibro());
        }
        QString x = fileImmagine->text();
        if(x != "NULL")
        {
            libro->setImmagine(libro->getTitolo() + x.mid(x.length()-4));
            QFile::copy(x, libro->getImmagine());
        }

        QList<QString> list;
        for(int i=0; i < autoriList->count(); ++i)
          list.append(autoriList->item(i)->text());

        if(!list.isEmpty()) libro->setAutori(list);

        list.clear();
        for(int i=0; i < generiList->count(); ++i)
          list.append(generiList->item(i)->text());

        if(!list.isEmpty()) libro->setGeneri(list);

        list.clear();
        for(int i=0; i < curatoriList->count(); ++i)
          list.append(curatoriList->item(i)->text());

        if(!list.isEmpty()) libro->setCuratori(list);

        logic->addBook(libro);
        emit(updateBook());
        BookWidget* temp = new BookWidget(libro);
        close();
        temp->show();
    }
    else
    {
        if(titoloEdit->text().isEmpty()) titoloLabel->setText("Questo campo non può essere vuoto");
        else titoloLabel->setText("Un libro con lo stesso titolo è\ngià presente nel catablogo");
        titoloLabel->show();
    }
}

void BookWidget::aggiornaSlot()
{
    Book* nuovo = new Book(libro->getTitolo());
    nuovo->setDataPubblicazione(dataPubblicazioneEdit->date());
    nuovo->setLingua(linguaEdit->text());
    nuovo->setDescrizione(descrizioneEdit->text());
    nuovo->setNumeroPagine(numeroPagineEdit->text().toInt());
    nuovo->setEditore(editoreEdit->text());
    nuovo->setCollana(collanaEdit->text());

    if(fileLibro->text() != libro->getLibro() &&  fileLibro->text()!= "NULL")
    {
        if(libro->getLibro().isEmpty())
        {
            nuovo->setLibro(nuovo->getTitolo() + ".pdf");
        }
        else
        {
            QFile::remove(libro->getLibro());
            nuovo->setLibro(libro->getLibro());
        }
        QFile::copy(fileLibro->text(), nuovo->getLibro());
    }
    else if(fileLibro->text() == libro->getLibro())
    {
        nuovo->setLibro(libro->getLibro());
    }
    libro->setLibro("");

    if(fileImmagine->text() != libro->getImmagine() && fileImmagine->text()!= "NULL")
    {
        QString x = fileImmagine->text().mid(fileImmagine->text().length()-4);
        if(libro->getImmagine().isEmpty())
        {
            nuovo->setImmagine(nuovo->getTitolo() + x);
        }
        else
        {
            QFile::remove(libro->getImmagine());
            if(libro->getImmagine().mid(libro->getImmagine().length()-4) != x) //controllo se le estensioni sono uguali
                nuovo->setImmagine(nuovo->getTitolo() + x);
            else
                nuovo->setImmagine(libro->getImmagine());
        }
        QFile::copy(fileImmagine->text(), nuovo->getImmagine());
    }
    else if(fileImmagine->text() == libro->getImmagine())
    {
        nuovo->setImmagine(libro->getImmagine());
    }
    libro->setImmagine("");

    QList<QString> list;
    for(int i=0; i < autoriList->count(); ++i)
      list.append(autoriList->item(i)->text());

    if(!list.isEmpty()) nuovo->setAutori(list);

    list.clear();
    for(int i=0; i < generiList->count(); ++i)
      list.append(generiList->item(i)->text());

    if(!list.isEmpty()) nuovo->setGeneri(list);

    list.clear();
    for(int i=0; i < curatoriList->count(); ++i)
      list.append(curatoriList->item(i)->text());

    if(!list.isEmpty()) nuovo->setCuratori(list);

    logic->updateBook(nuovo);
    emit(updateBook());
    close();
}

void BookWidget::getAutoreSlot()
{
    element = autoriList->currentItem();
    hide();
    removeAutore->show();
}

void BookWidget::getGenereSlot()
{
    element = generiList->currentItem();
    hide();
    removeGenere->show();
}

void BookWidget::getCuratoreSlot()
{
    element = curatoriList->currentItem();
    hide();
    removeCuratore->show();
}

void BookWidget::aggiungiAutoreSlot()
{
    QString x = autoreEdit->text();
    if(!x.isEmpty())
    {
        for(int i=0; i < autoriList->count(); ++i)
        {
            if(autoriList->item(i)->text() == x)
                return;
        }
        autoriList->addItem(autoreEdit->text());
        autoreEdit->setText("");
    }
}

void BookWidget::rimuoviAutoreSlot()
{
    autoriList->removeItemWidget(element);
    delete element;
    removeAutore->hide();
    element = 0;

}

void BookWidget::aggiungiGenereSlot()
{
    QString x = genereEdit->text();
    if(!x.isEmpty())
    {
        for(int i=0; i < generiList->count(); ++i)
        {
            if(generiList->item(i)->text() == x)
                return;
        }
        generiList->addItem(x);
        genereEdit->setText("");
    }
}

void BookWidget::rimuoviGenereSlot()
{
    generiList->removeItemWidget(element);
    delete element;
    removeGenere->hide();
    element = 0;
}

void BookWidget::aggiungiCuratoreSlot()
{
    QString x = curatoreEdit->text();
    if(!x.isEmpty())
    {
        for(int i=0; i < curatoriList->count(); ++i)
        {
            if(curatoriList->item(i)->text() == x)
                return;
        }
        curatoriList->addItem(x);
        curatoreEdit->setText("");
    }
}

void BookWidget::rimuoviCuratoreSlot()
{
    curatoriList->removeItemWidget(element);
    delete element;
    removeCuratore->hide();
    element = 0;
}

void BookWidget::apriFile()
{
    QString temp = QFileDialog::getOpenFileName(this, tr("Open File"), "C://", tr("Pdf File (*.pdf)"));
    if(!temp.isEmpty())
    {
        fileLibro->setText(temp);
    }
}

void BookWidget::apriImmagine()
{
    QString temp = QFileDialog::getOpenFileName(this, tr("Open Image"), "C://", tr("Immagine jpg (*.jpg);;Immagine png (*.png)"));
    if(!temp.isEmpty())
    {
        fileImmagine->setText(temp);
    }
}

void BookWidget::visualizzaPdfSlot()
{
    QDesktopServices::openUrl(QUrl::fromLocalFile(libro->getLibro()));
}
