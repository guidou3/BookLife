#ifndef LISTALAVORIWIDGET_H
#define LISTALAVORIWIDGET_H

#include "listawidget.h"
#include "lightnovelwidget.h"

class ListaLavoriWidget : public ListaWidget
{
    Q_OBJECT

public:
    explicit ListaLavoriWidget(Client*, QWidget *parent = 0);

private:
    LightNovelWidget* lnw;

    QHBoxLayout* central;

    QVBoxLayout* risultato;

public slots:
    void getSlot();
    void updateSlot();
    void hideSlot();

};
#endif // LISTALAVORIWIDGET_H
