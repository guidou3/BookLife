#ifndef LISTAUTENTIWIDGET_H
#define LISTAUTENTIWIDGET_H

#include "listawidget.h"

class ListaUtentiWidget : public ListaWidget
{
    Q_OBJECT

public:
    explicit ListaUtentiWidget(Client*, QWidget *parent = 0);

    void hideAll();

private:
    QPushButton* rimuovi;

public slots:
    void getSlot();
    void updateSlot();
    void rimuoviSlot();
    void hideSlot();
};

#endif // LISTAUTENTIWIDGET_H
