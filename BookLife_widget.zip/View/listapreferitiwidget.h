#ifndef LISTAPREFERITIWIDGET_H
#define LISTAPREFERITIWIDGET_H

#include "listawidget.h"
#include "lightnovelwidget.h"
#include "bookwidget.h"

class ListaPreferitiWidget : public ListaWidget
{
    Q_OBJECT

public:
    explicit ListaPreferitiWidget(Client*, QWidget *parent = 0);

    void hideAll();

private:
    QPushButton* visualizza;
    QPushButton* rimuovi;

public slots:
    void getSlot();
    void updateSlot();
    void visualizzaSlot();
    void rimuoviSlot();
    void hideSlot();
};

#endif // LISTAPREFERITIWIDGET_H
