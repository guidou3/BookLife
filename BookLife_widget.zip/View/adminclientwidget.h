#ifndef ADMINCLIENTWIDGET_H
#define ADMINCLIENTWIDGET_H


#include "clientwidget.h"
#include "listalibriwidget.h"
#include "listautentiwidget.h"

class AdminClientWidget : public ClientWidget {

    Q_OBJECT

public:
    explicit AdminClientWidget(Session*, QWidget *parent = 0);
    ~AdminClientWidget();

private:

    // campi dati grafici
    ListaLibriWidget* book;
    ListaLibriWidget* ln;
    ListaUtentiWidget* utenti;

public slots:
    void hideSlot();
};

#endif // ADMINCLIENTWIDGET_H
