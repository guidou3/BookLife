#ifndef LISTAWIDGET_H
#define LISTAWIDGET_H

#include "Controller/client.h"

#include <QListWidget>
#include <QPushButton>
#include <QBoxLayout>
#include <QGroupBox>

class ListaWidget : public QWidget
{
    Q_OBJECT

public:
    explicit ListaWidget(Client*, QString, QWidget *parent = 0);

protected:
    Client* logic;

    QListWidget* lista;

    QHBoxLayout* layout;
    QVBoxLayout* mainLayout;
    QGroupBox* listaBox;

signals:
    void selected();

public slots:
    virtual void getSlot() =0;
    virtual void hideSlot() =0;

};

#endif // LISTAWIDGET_H
