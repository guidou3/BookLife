#ifndef BOOKWIDGET_H
#define BOOKWIDGET_H

#include "Controller/client.h"

#include <QBoxLayout>
#include <QPushButton>
#include <QLabel>
#include <QFormLayout>
#include <QListWidget>
#include <QGroupBox>
#include <QLineEdit>
#include <QDateEdit>
#include <QWidget>
#include <QScrollArea>
#include <QPixmap>
#include <QDesktopServices>
#include <QUrl>
#include <QFileDialog>

class BookWidget : public QWidget
{
    Q_OBJECT

public:
    explicit BookWidget(Book*, Client*, QWidget *parent = 0);
    explicit BookWidget(Client*, QWidget *parent = 0);
    explicit BookWidget(Book*, QWidget *parent = 0);
    ~BookWidget();

private:
    // campi dati logici
    Client* logic;
    Book* libro;

    // campi dati grafici
    QVBoxLayout* mainLayout;
    QHBoxLayout* centralLayout;
    QGroupBox* visualizzaBox;

    QLabel* titoloSchedaLabel;

    // campi dati grafici per la visualizzazione dei dati
    QLabel* titoloLabel;
    QListWidget* autoriList;
    QLabel* dataPubblicazioneLabel;
    QLabel* linguaLabel;
    QListWidget* generiList;
    QLabel* descrizioneLabel;
    QLabel* fileImmagine;
    QLabel* immagineLabel;
    QLabel* numeroPagineLabel;
    QListWidget* curatoriList;
    QLabel* editoreLabel;
    QLabel* collanaLabel;
    QLabel* fileLibro;

    QListWidgetItem* element;

    // campi dati grafici per l'inserimento/modfica dei dati
    QLineEdit* titoloEdit;
    QDateEdit* dataPubblicazioneEdit;
    QLineEdit* linguaEdit;
    QLineEdit* descrizioneEdit;
    QLineEdit* numeroPagineEdit;
    QLineEdit* editoreEdit;
    QLineEdit* collanaEdit;
    QLineEdit* autoreEdit;
    QLineEdit* genereEdit;
    QLineEdit* curatoreEdit;

    // pulsanti
    QPushButton* linkToPdf;

    QPushButton* addAutore;
    QPushButton* removeAutore;
    QPushButton* addGenere;
    QPushButton* removeGenere;
    QPushButton* addCuratore;
    QPushButton* removeCuratore;

    QPushButton* annulla;
    QPushButton* salva;

    //metodi privati
    void initialize();
    void hide();

signals:
    void updateBook();

public slots:
    void salvaSlot(); // procedura per il salvataggio di un nuovo book nel database
    void aggiornaSlot(); // procedura per l'update dei dati di un book nel database
    void getAutoreSlot(); // procedura per il selezionamento di un item dalla lista autori e visualizzazione del pulsante di rimozione
    void getGenereSlot(); // procedura per il selezionamento di un item dalla lista generi e visualizzazione del pulsante di rimozione
    void getCuratoreSlot(); // procedura per il selezionamento di un item dalla lista curatori e visualizzazione del pulsante di rimozione
    void aggiungiAutoreSlot(); // procedura per l'inserimento di una nuova voce nella lista autori
    void rimuoviAutoreSlot(); // procedura per la rimozione di una nuova voce dalla lista autori
    void aggiungiGenereSlot(); // procedura per l'inserimento di una nuova voce nella lista generi
    void rimuoviGenereSlot(); // procedura per la rimozione di una nuova voce dalla lista generi
    void aggiungiCuratoreSlot(); // procedura per l'inserimento di una nuova voce nella lista curatori
    void rimuoviCuratoreSlot(); // procedura per la rimozione di una nuova voce dalla lista curatori
    void apriFile(); // procedura per il selezionamento di un file pdf dai file presenti nella macchina
    void apriImmagine(); // procedura per il selezionamento di un file immagine (.jpg o .png) dai file presenti nella macchina
    void visualizzaPdfSlot(); // procedura per la visualizzazione del file pdf mediante software della macchina
};

#endif // BOOKWIDGET_H
