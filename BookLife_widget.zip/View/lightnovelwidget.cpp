#include "lightnovelwidget.h"
#include "writerclientwidget.h"

LightNovelWidget::~LightNovelWidget(){}

LightNovelWidget::LightNovelWidget(Light_novel* ln, Client* c, QWidget *parent) : QWidget(parent), logic(c), lightNovel(ln)
{
    if(lightNovel == NULL)
    {
        cerr << "Light novel non fornita" << endl;
        return;
    }
    mainLayout = new QVBoxLayout;
    centralLayout = new QHBoxLayout;
    visualizzaBox = new QGroupBox;

    layCap = new QVBoxLayout;

    titoloLabel = new QLabel;
    dataPubblicazioneLabel = new QLabel;
    linguaLabel = new QLabel;
    descrizioneLabel = new QLabel;
    immagineLabel = new QLabel;
    capitoli_tradottiLabel = new QLabel;
    capitoli_scrittiLabel = new QLabel;
    completatoLabel = new QLabel;
    lingua_originaleLabel = new QLabel;

    autoriList = new QListWidget;
    generiList = new QListWidget;
    traduttoriList = new QListWidget;
    capitoliList = new QListWidget;

    titoloLabel->setText(lightNovel->getTitolo());
    dataPubblicazioneLabel->setText(lightNovel->getDataPubblicazione().toString());
    linguaLabel->setText(lightNovel->getLingua());
    descrizioneLabel->setText(lightNovel->getDescrizione());
    descrizioneLabel->setWordWrap(true);
    capitoli_tradottiLabel->setText(QString::number(lightNovel->getCapitoliTradotti()));
    capitoli_scrittiLabel->setText(QString::number(lightNovel->getCapitoliScritti()));
    if(lightNovel->isCompletato()) completatoLabel->setText("Vero");
    else completatoLabel->setText("Falso");
    lingua_originaleLabel->setText(lightNovel->getLinguaOriginale());

    autoriList->addItems(lightNovel->getAutori());
    autoriList->setMaximumHeight(100);
    generiList->addItems(lightNovel->getGeneri());
    generiList->setMaximumHeight(100);
    traduttoriList->addItems(lightNovel->getTraduttori());
    traduttoriList->setMaximumHeight(100);



    if(!lightNovel->getImmagine().isEmpty())
    {
        QPixmap pix(lightNovel->getImmagine());
        immagineLabel->setPixmap(pix.scaled(300, 450, Qt::KeepAspectRatio));
    }
    else
    {
        immagineLabel->hide();
    }

    QFormLayout* flayout = new QFormLayout;

    flayout->addRow("Titolo: ", titoloLabel);
    flayout->addRow("Data di pubblicazione: ", dataPubblicazioneLabel);
    flayout->addRow("Lingua: ", linguaLabel);
    flayout->addRow("Descrizione: ", descrizioneLabel);
    flayout->addRow("Capitoli scritti: ", capitoli_scrittiLabel);
    flayout->addRow("Capitoli tradotti: ", capitoli_tradottiLabel);
    flayout->addRow("Completato: ", completatoLabel);
    flayout->addRow("Lingua originale: ", lingua_originaleLabel);
    flayout->addRow("Autori: ", autoriList);
    flayout->addRow("Generi: ", generiList);
    flayout->addRow("Traduttori: ", traduttoriList);


    if(logic->getTipoClient() == 1 && logic->getSession()->getAccountType() == 1 && dynamic_cast<Scrittore*>(logic->getSession()->utenteLoggato)->isMine(lightNovel))
        mine = true;
    else
        mine = false;

    layCap->addWidget(immagineLabel);
    layCap->setAlignment(immagineLabel, Qt::AlignTop);
    capitoliListInitialize();

    visualizzaBox->setLayout(flayout);
    visualizzaBox->setTitle("Informazioni sulla light novel");
    centralLayout->addWidget(visualizzaBox);
    centralLayout->addLayout(layCap);
    mainLayout->addLayout(centralLayout);
    setLayout(mainLayout);
}

LightNovelWidget::LightNovelWidget(Client* c, Light_novel* ln, QWidget *parent) : QWidget(parent), logic(c), lightNovel(ln)
{
    if(lightNovel == NULL)
    {
        cerr << "Light novel non fornita" << endl;
        return;
    }

    initialize();

    titoloSchedaLabel->setText("Modifica informazioni light novel");

    titoloEdit->setText(lightNovel->getTitolo());
    titoloEdit->setEnabled(false);
    dataPubblicazioneEdit->setDate(lightNovel->getDataPubblicazione());
    linguaEdit->setText(lightNovel->getLingua());
    descrizioneEdit->setText(lightNovel->getDescrizione());
    capitoli_tradottiEdit->setText(QString::number(lightNovel->getCapitoliTradotti()));
    capitoli_scrittiEdit->setText(QString::number(lightNovel->getCapitoliScritti()));
    lingua_originaleEdit->setText(lightNovel->getLinguaOriginale());

    fileImmagine->setText(lightNovel->getImmagine());
    if(fileImmagine->text().isEmpty()) fileImmagine->setText("NULL");

    autoriList->addItems(lightNovel->getAutori());
    autoriList->setMaximumHeight(100);
    generiList->addItems(lightNovel->getGeneri());
    generiList->setMaximumHeight(100);
    traduttoriList->addItems(lightNovel->getTraduttori());
    traduttoriList->setMaximumHeight(100);

    if(lightNovel->isCompletato()) completatoTrue->setChecked(true);
    else completatoFalse->setChecked(true);

    connect(salva,SIGNAL(clicked()),this,SLOT(aggiornaSlot()));
}

LightNovelWidget::LightNovelWidget(Client* c, QWidget *parent) : QWidget(parent, Qt::Window), logic(c)
{
    lightNovel = new Light_novel("Titolo temporaneo");

    initialize();

    titoloSchedaLabel->setText("Crea una nuova light novel");

    fileImmagine->setText("NULL");

    completatoFalse->setChecked(true);

    connect(salva,SIGNAL(clicked()),this,SLOT(salvaSlot()));
}

void LightNovelWidget::initialize()
{
    mainLayout = new QVBoxLayout;
    visualizzaBox = new QGroupBox;

    titoloEdit = new QLineEdit;
    dataPubblicazioneEdit = new QDateEdit;
    linguaEdit = new QLineEdit;
    descrizioneEdit = new QLineEdit;
    capitoli_tradottiEdit = new QLineEdit;
    capitoli_scrittiEdit = new QLineEdit;
    lingua_originaleEdit = new QLineEdit;
    autoreEdit = new QLineEdit;
    genereEdit = new QLineEdit;
    traduttoreEdit = new QLineEdit;

    capitoli_tradottiEdit->setValidator(new QIntValidator(0, 2000, this));
    capitoli_scrittiEdit->setValidator(new QIntValidator(0, 2000, this));

    fileImmagine = new QLabel;

    autoriList = new QListWidget;
    generiList = new QListWidget;
    traduttoriList = new QListWidget;

    completatoTrue = new QRadioButton;
    completatoFalse = new QRadioButton;

    addAutore = new QPushButton;
    removeAutore = new QPushButton;
    addGenere = new QPushButton;
    removeGenere = new QPushButton;
    addTraduttore = new QPushButton;
    removeTraduttore = new QPushButton;

    annulla = new QPushButton;
    salva = new QPushButton;
    QPushButton* addImmagine = new QPushButton;

    titoloLabel = new QLabel;
    titoloLabel->hide();

    completatoTrue->setText("Vero");
    completatoFalse->setText("Falso");

    addAutore->setText("Inserisci");
    removeAutore->setText("Rimuovi");
    removeAutore->hide();
    addGenere->setText("Inserisci");
    removeGenere->setText("Rimuovi");
    removeGenere->hide();
    addTraduttore->setText("Inserisci");
    removeTraduttore->setText("Rimuovi");
    removeTraduttore->hide();
    addImmagine->setText("Aggiungi immagine");
    annulla->setText("ANNULLA");
    annulla->setMaximumWidth(150);
    salva->setText("SALVA");
    salva->setMaximumWidth(150);

    autoriList->setMaximumHeight(100);
    generiList->setMaximumHeight(100);
    traduttoriList->setMaximumHeight(100);

    connect(autoriList,SIGNAL(itemDoubleClicked(QListWidgetItem*)),this,SLOT(getAutoreSlot()));
    connect(generiList,SIGNAL(itemDoubleClicked(QListWidgetItem*)),this,SLOT(getGenereSlot()));
    connect(traduttoriList,SIGNAL(itemDoubleClicked(QListWidgetItem*)),this,SLOT(getTraduttoreSlot()));
    connect(addAutore,SIGNAL(clicked()),this,SLOT(aggiungiAutoreSlot()));
    connect(removeAutore,SIGNAL(clicked()),this,SLOT(rimuoviAutoreSlot()));
    connect(addGenere,SIGNAL(clicked()),this,SLOT(aggiungiGenereSlot()));
    connect(removeGenere,SIGNAL(clicked()),this,SLOT(rimuoviGenereSlot()));
    connect(addTraduttore,SIGNAL(clicked()),this,SLOT(aggiungiTraduttoreSlot()));
    connect(removeTraduttore,SIGNAL(clicked()),this,SLOT(rimuoviTraduttoreSlot()));
    connect(addImmagine,SIGNAL(clicked()),this,SLOT(apriImmagine()));
    connect(annulla,SIGNAL(clicked()),this,SLOT(close()));

    QVBoxLayout* v1 = new QVBoxLayout;
    v1->addWidget(autoriList);
    v1->addWidget(removeAutore);

    QVBoxLayout* v2 = new QVBoxLayout;
    v2->addWidget(generiList);
    v2->addWidget(removeGenere);

    QVBoxLayout* v3 = new QVBoxLayout;
    v3->addWidget(traduttoriList);
    v3->addWidget(removeTraduttore);

    QHBoxLayout* h1 = new QHBoxLayout;
    h1->addWidget(autoreEdit);
    h1->addWidget(addAutore);

    QHBoxLayout* h2 = new QHBoxLayout;
    h2->addWidget(genereEdit);
    h2->addWidget(addGenere);

    QHBoxLayout* h3 = new QHBoxLayout;
    h3->addWidget(traduttoreEdit);
    h3->addWidget(addTraduttore);

    QHBoxLayout* rb = new QHBoxLayout;
    rb->addWidget(completatoFalse);
    rb->addWidget(completatoTrue);

    QFormLayout* flayout = new QFormLayout;

    flayout->addRow("Titolo: ", titoloEdit);
    flayout->addRow("", titoloLabel);
    flayout->addRow("Data di pubblicazione: ", dataPubblicazioneEdit);
    flayout->addRow("Lingua: ", linguaEdit);
    flayout->addRow("Descrizione: ", descrizioneEdit);
    flayout->addRow("Capitoli scritti: ", capitoli_scrittiEdit);
    flayout->addRow("Capitoli tradotti: ", capitoli_tradottiEdit);
    flayout->addRow("Completato: ", rb);
    flayout->addRow("Lingua originale: ", lingua_originaleEdit);
    flayout->addRow("Autori: ", v1);
    flayout->addRow("Nuovo autore: ", h1);
    flayout->addRow("Generi: ", v2);
    flayout->addRow("Nuovo genere: ", h2);
    flayout->addRow("Traduttori: ", v3);
    flayout->addRow("Nuovo traduttore: ", h3);
    flayout->addRow("Immagine selezionata: ", fileImmagine);
    flayout->addRow("", addImmagine);

    QHBoxLayout* buttons = new QHBoxLayout;

    buttons->addWidget(annulla);
    buttons->addSpacing(50);
    buttons->addWidget(salva);

    visualizzaBox->setLayout(flayout);

    titoloSchedaLabel = new QLabel;
    QFont font = QFont("arial", 12, QFont::Bold);
    titoloSchedaLabel->setFont(font);

    QScrollArea* scroll = new QScrollArea;
    scroll->setWidget(visualizzaBox);
    scroll->adjustSize();
    scroll->setWidgetResizable(true);

    QVBoxLayout* mall = new QVBoxLayout;
    mall->addWidget(scroll);

    mainLayout->addWidget(titoloSchedaLabel);
    mainLayout->addLayout(mall);
    mainLayout->addLayout(buttons);
    setLayout(mainLayout);
}

void LightNovelWidget::capitoliListInitialize()
{
    QList<Capitolo*> temp = lightNovel->getCapitoli();
    QStringList cap;

    for(int i=0; i<temp.size(); ++i)
    {
        cap.append(temp.at(i)->getTitolo());
    }

    capitoliList->addItems(cap);
    capitoliList->setMaximumWidth(300);
    layCap->addWidget(capitoliList);
    if(mine)
    {
        visualizzaCapitolo = new QPushButton;
        visualizzaCapitolo->setText("Visualizza");

        changeCapitolo = new QPushButton;
        changeCapitolo->setText("Modifica");

        addCapitolo = new QPushButton;
        addCapitolo->setText("Aggiungi nuovo");

        connect(capitoliList,SIGNAL(itemDoubleClicked(QListWidgetItem*)),this,SLOT(getCapitoloSlot()));
        connect(visualizzaCapitolo,SIGNAL(clicked()),this,SLOT(visualizzaCapitoloSlot()));
        connect(changeCapitolo,SIGNAL(clicked()),this,SLOT(modificaCapitoloSlot()));
        connect(addCapitolo,SIGNAL(clicked()),this,SLOT(aggiungiCapitoloSlot()));

        layCap->addWidget(visualizzaCapitolo);
        visualizzaCapitolo->hide();
        layCap->addWidget(changeCapitolo);
        changeCapitolo->hide();
        layCap->addWidget(addCapitolo);
    }
    else
    {
        connect(capitoliList,SIGNAL(itemDoubleClicked(QListWidgetItem*)),this,SLOT(visualizzaCapitoloCorrenteSlot()));
    }
}

void LightNovelWidget::salvaSlot()
{
    if(!titoloEdit->text().isEmpty() && !logic->getSession()->db->findLightNovel(titoloEdit->text()) && !logic->getSession()->db->findBook(titoloEdit->text()))
    {
        lightNovel->setTitolo(titoloEdit->text());
        if(!dataPubblicazioneEdit->text().isEmpty()) lightNovel->setDataPubblicazione(dataPubblicazioneEdit->date());
        if(!linguaEdit->text().isEmpty()) lightNovel->setLingua(linguaEdit->text());
        if(!descrizioneEdit->text().isEmpty()) lightNovel->setDescrizione(descrizioneEdit->text());
        if(!capitoli_tradottiEdit->text().isEmpty()) lightNovel->setCapitoliTradotti(capitoli_tradottiEdit->text().toInt());
        if(!capitoli_scrittiEdit->text().isEmpty()) lightNovel->setCapitoliScritti(capitoli_scrittiEdit->text().toInt());

        lightNovel->setCompletato(completatoTrue->isChecked()); // gestione radio button

        if(!lingua_originaleEdit->text().isEmpty()) lightNovel->setLinguaOriginale(lingua_originaleEdit->text());

        QString x = fileImmagine->text();
        if(x != "NULL")
        {
            lightNovel->setImmagine(lightNovel->getTitolo() + x.mid(x.length()-4));
            QFile::copy(x, lightNovel->getImmagine());
        }

        QList<QString> list;
        for(int i=0; i < autoriList->count(); ++i)
          list.append(autoriList->item(i)->text());

        if(!list.isEmpty()) lightNovel->setAutori(list);

        list.clear();
        for(int i=0; i < generiList->count(); ++i)
          list.append(generiList->item(i)->text());

        if(!list.isEmpty()) lightNovel->setGeneri(list);

        list.clear();
        for(int i=0; i < traduttoriList->count(); ++i)
        {
            list.append(traduttoriList->item(i)->text());
            Scrittore* sc = dynamic_cast<Scrittore*>(logic->getSession()->db->findUtente(list.at(i)));
            if(sc) sc->setMine(lightNovel, true);
        }

        if(!list.isEmpty()) lightNovel->setTraduttori(list);

        logic->addLightNovel(lightNovel);
        emit(updateLightNovel());
        LightNovelWidget* temp = new LightNovelWidget(lightNovel, logic);
        close();
        temp->show();
    }
    else
    {
        if(titoloEdit->text().isEmpty()) titoloLabel->setText("Questo campo non può essere vuoto");
        else titoloLabel->setText("Un libro con lo stesso titolo è\ngià presente nel catalogo");
        titoloLabel->show();
    }
}

void LightNovelWidget::aggiornaSlot()
{
    Light_novel* nuovo = new Light_novel(lightNovel->getTitolo());
    nuovo->setDataPubblicazione(dataPubblicazioneEdit->date());
    nuovo->setLingua(linguaEdit->text());
    nuovo->setDescrizione(descrizioneEdit->text());
    nuovo->setCapitoliTradotti(capitoli_tradottiEdit->text().toInt());
    nuovo->setCapitoliScritti(capitoli_scrittiEdit->text().toInt());

    nuovo->setCompletato(completatoTrue->isChecked()); // gestione radio button

    nuovo->setLinguaOriginale(lingua_originaleEdit->text());

    if(fileImmagine->text() != lightNovel->getImmagine() && fileImmagine->text()!= "NULL")
    {
        QString x = fileImmagine->text().mid(fileImmagine->text().length()-4);
        if(lightNovel->getImmagine().isEmpty())
        {
            nuovo->setImmagine(nuovo->getTitolo() + x);
            cout << "campo precedentemente vuoto: " << nuovo->getImmagine().toStdString() << endl;
        }
        else
        {
            cout << "campo precedentemente non vuoto" << endl;
            QFile::remove(lightNovel->getImmagine());
            if(lightNovel->getImmagine().mid(lightNovel->getImmagine().length()-4) != x) //controllo se le estensioni sono uguali
            {
                nuovo->setImmagine(nuovo->getTitolo() + x);
                cout << "estensione diversa: " << nuovo->getImmagine().toStdString() << endl;
            }
            else
            {
                nuovo->setImmagine(lightNovel->getImmagine());
                cout << "stessa estensione: " << nuovo->getImmagine().toStdString() << endl;
            }
        }
        QFile::copy(fileImmagine->text(), nuovo->getImmagine());
    }
    else if(fileImmagine->text() == lightNovel->getImmagine() && fileImmagine->text()!= "NULL")
    {
        nuovo->setImmagine(lightNovel->getImmagine());
    }
    lightNovel->setImmagine("");

    QList<QString> list;
    for(int i=0; i < autoriList->count(); ++i)
      list.append(autoriList->item(i)->text());

    if(!list.isEmpty()) nuovo->setAutori(list);

    list.clear();
    for(int i=0; i < generiList->count(); ++i)
      list.append(generiList->item(i)->text());

    if(!list.isEmpty()) nuovo->setGeneri(list);

    list.clear();
    QStringList qsl = lightNovel->getTraduttori();
    for(int i=0; i < traduttoriList->count(); ++i)
    {
        list.append(traduttoriList->item(i)->text());
        if(!qsl.contains(list.at(i)))
        {
            Scrittore* sc = dynamic_cast<Scrittore*>(logic->getSession()->db->findUtente(list.at(i)));
            if(sc) sc->setMine(nuovo, true);
        }
    }
    for(int i=0; i<qsl.size(); ++i)
    {
        if(!list.contains(qsl.at(i)))
        {
            Scrittore* sc = dynamic_cast<Scrittore*>(logic->getSession()->db->findUtente(list.at(i)));
            if(sc) sc->setMine(nuovo, false);
        }
    }


    if(!list.isEmpty())
        nuovo->setTraduttori(list);


    logic->updateLightNovel(nuovo);
    emit(updateLightNovel());
    close();
}

void LightNovelWidget::hide()
{
    if(!removeAutore->isHidden()) removeAutore->hide();
    if(!removeGenere->isHidden()) removeGenere->hide();
    if(!removeTraduttore->isHidden()) removeTraduttore->hide();
}

void LightNovelWidget::hideVisualize()
{
    if(mine)
    {
        if(!changeCapitolo->isHidden()) changeCapitolo->hide();
        if(!visualizzaCapitolo->isHidden()) visualizzaCapitolo->hide();
    }
}

void LightNovelWidget::getAutoreSlot()
{
    element = autoriList->currentItem();
    hide();
    removeAutore->show();
}

void LightNovelWidget::getGenereSlot()
{
    element = generiList->currentItem();
    hide();
    removeGenere->show();
}

void LightNovelWidget::getTraduttoreSlot()
{
    element = traduttoriList->currentItem();
    hide();
    removeTraduttore->show();
}

void LightNovelWidget::aggiungiAutoreSlot()
{
    QString x = autoreEdit->text();
    if(!x.isEmpty())
    {
        for(int i=0; i < autoriList->count(); ++i)
        {
            if(autoriList->item(i)->text() == x)
                return;
        }
        autoriList->addItem(autoreEdit->text());
        autoreEdit->setText("");
    }
}

void LightNovelWidget::rimuoviAutoreSlot()
{
    autoriList->removeItemWidget(element);
    delete element;
    removeAutore->hide();
    element = 0;

}

void LightNovelWidget::aggiungiGenereSlot()
{
    QString x = genereEdit->text();
    if(!x.isEmpty())
    {
        for(int i=0; i < generiList->count(); ++i)
        {
            if(generiList->item(i)->text() == x)
                return;
        }
        generiList->addItem(x);
        genereEdit->setText("");
    }
}

void LightNovelWidget::rimuoviGenereSlot()
{
    generiList->removeItemWidget(element);
    delete element;
    removeGenere->hide();
    element = 0;
}

void LightNovelWidget::aggiungiTraduttoreSlot()
{
    QString x = traduttoreEdit->text();
    if(!x.isEmpty())
    {
        for(int i=0; i < traduttoriList->count(); ++i)
        {
            if(traduttoriList->item(i)->text() == x)
                return;
        }
        traduttoriList->addItem(x);
        traduttoreEdit->setText("");
    }
}

void LightNovelWidget::rimuoviTraduttoreSlot()
{
    traduttoriList->removeItemWidget(element);
    delete element;
    removeTraduttore->hide();
    element = 0;
}

void LightNovelWidget::aggiungiCapitoloSlot()
{
    CapitoloWidget* cw = new CapitoloWidget(lightNovel);
    cw->show();
    connect(cw,SIGNAL(updateCapitoli()),this,SLOT(updateListaCapitoliSlot()));
}

void LightNovelWidget::modificaCapitoloSlot()
{
    CapitoloWidget* cw = new CapitoloWidget(lightNovel, index);
    cw->show();
    connect(cw,SIGNAL(updateNomeCapitolo()),this,SLOT(updateListaCapitoliSlot()));
}

void LightNovelWidget::getCapitoloSlot()
{
    QString x = capitoliList->currentItem()->text();
    index = lightNovel->getCapitoloIndex(x);
    if(index != -1)
    {
        cap = lightNovel->getCapitolo(index);
        hideVisualize();
        changeCapitolo->show();
        visualizzaCapitolo->show();
    }
}

void LightNovelWidget::visualizzaCapitoloSlot()
{
    if(cap != NULL)
    {
        CapitoloWidget* cw = new CapitoloWidget(cap);
        cw->show();
    }
    else
    {
        cout << "errore" << endl;
    }

}

void LightNovelWidget::visualizzaCapitoloCorrenteSlot()
{
    QString x = capitoliList->currentItem()->text();
    index = lightNovel->getCapitoloIndex(x);
    if(index != -1)
    {
        cap = lightNovel->getCapitolo(index);
        if(cap)
        {
            CapitoloWidget* cw = new CapitoloWidget(cap);
            cw->show();
        }
    }
}

void LightNovelWidget::updateListaCapitoliSlot()
{
    QList<Capitolo*> temp = lightNovel->getCapitoli();
    QStringList cap;

    for(int i=0; i<temp.size(); ++i)
    {
        cap.append(temp.at(i)->getTitolo());
    }
    capitoliList->clear();
    capitoliList->addItems(cap);
}

void LightNovelWidget::apriImmagine()
{
    QString temp = QFileDialog::getOpenFileName(this, tr("Open Image"), "C://", tr("Immagine jpg (*.jpg);;Immagine png (*.png)"));
    if(!temp.isEmpty())
    {
        fileImmagine->setText(temp);
    }
}
