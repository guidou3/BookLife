#include "listalibriwidget.h"

ListaLibriWidget::ListaLibriWidget(Client* c, QString title, bool ad, QWidget *parent): ListaWidget(c, "Lista di "+title, parent)
{
    admin = ad;
    type = title;

    if(type == "Book")
        lista->addItems(logic->getListaBook());
    else
        lista->addItems(logic->getListaLightNovel());

    visualizza = new QPushButton;
    visualizza->setText("Visualizza");
    visualizza->hide();

    connect(visualizza,SIGNAL(clicked()),this,SLOT(visualizzaSlot()));

    mainLayout->addWidget(visualizza);

    if(admin)
    {
        modifica = new QPushButton;
        modifica->setText("Modifica");

        rimuovi = new QPushButton;
        rimuovi->setText("Rimuovi");

        aggiungi = new QPushButton;
        aggiungi->setText("Aggiungi");

        connect(rimuovi,SIGNAL(clicked()),this,SLOT(rimuoviSlot()));
        connect(modifica,SIGNAL(clicked()),this,SLOT(modificaSlot()));
        connect(aggiungi,SIGNAL(clicked()),this,SLOT(aggiungiSlot()));

        mainLayout->addWidget(modifica);
        modifica->hide();
        mainLayout->addWidget(rimuovi);
        rimuovi->hide();
    }
    else
    {
        aggiungi = new QPushButton;
        aggiungi->setText("Aggiungi ai preferiti");
        aggiungi->hide();

        connect(aggiungi,SIGNAL(clicked()),this,SLOT(aggiungiPreferitoSlot()));
    }

    mainLayout->addWidget(aggiungi);
}

void ListaLibriWidget::getSlot()
{
    QString x = lista->currentItem()->text();

    if(type == "Book")
        logic->findBook(x);
    else
        logic->findLightNovel(x);

    if(logic->getLibroSelezionato())
    {
        emit(selected());
        if(admin)
        {
            visualizza->show();
            modifica->show();
            rimuovi->show();
        }
        else {
            visualizza->show();
            aggiungi->show();
        }

    }
    else {
        updateSlot();
    }
}

void ListaLibriWidget::updateSlot()
{
    hideSlot();
    logic->resetSelezionati();
    lista->clear();
    if(type == "Book")
        lista->addItems(logic->getListaBook());
    else
        lista->addItems(logic->getListaLightNovel());
}

void ListaLibriWidget::visualizzaSlot()
{
    Libro* libro = logic->getLibroSelezionato();
    if(libro->getType() =="Book") {
        BookWidget* bw = new BookWidget(dynamic_cast<Book*>(libro));
        bw->show();
    }
    else {
        LightNovelWidget* lnw = new LightNovelWidget(dynamic_cast<Light_novel*>(libro), logic);
        lnw->show();
    }
}

void ListaLibriWidget::rimuoviSlot()
{
    if(logic->getLibroSelezionato()->getType() == "Book")
    {
        QString libro = dynamic_cast<Book*>(logic->getLibroSelezionato())->getLibro();
        if(!libro.isNull())
            QFile::remove(libro);

    }
    QString immagine = logic->getLibroSelezionato()->getImmagine();

    if(!immagine.isNull())
        QFile::remove(immagine);

    logic->rimuoviLibro();
    hideSlot();
    updateSlot();
}

void ListaLibriWidget::aggiungiSlot()
{
    if(type == "Book")
    {
        BookWidget* bw = new BookWidget(logic);
        bw->show();
        connect(bw,SIGNAL(updateBook()),this,SLOT(updateSlot()));
    }
    else {
        LightNovelWidget* lnw = new LightNovelWidget(logic);
        lnw->show();
        connect(lnw,SIGNAL(updateLightNovel()),this,SLOT(updateSlot()));
    }
}

void ListaLibriWidget::aggiungiPreferitoSlot()
{
    logic->addPreferito();
    emit(updatePreferiti());
}

void ListaLibriWidget::modificaSlot()
{
    if(type == "Book")
    {
        BookWidget* bw = new BookWidget(dynamic_cast<Book*>(logic->getLibroSelezionato()), logic);
        bw->show();
        connect(bw,SIGNAL(updateBook()),this,SLOT(updateSlot()));
    }
    else {
        LightNovelWidget* lnw = new LightNovelWidget(logic, dynamic_cast<Light_novel*>(logic->getLibroSelezionato()));
        lnw->show();
        connect(lnw,SIGNAL(updateLightNovel()),this,SLOT(updateSlot()));
    }
}

void ListaLibriWidget::hideSlot()
{
    if(admin) {
        visualizza->hide();
        modifica->hide();
        rimuovi->hide();
    }
    else {
        visualizza->hide();
        aggiungi->hide();
    }

}
