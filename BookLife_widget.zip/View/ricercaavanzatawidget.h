#ifndef RICERCAAVANZATAWIDGET_H
#define RICERCAAVANZATAWIDGET_H

#include <QWidget>
#include "listarisultatiricercawidget.h"

class RicercaAvanzataWidget : public QWidget
{
    Q_OBJECT

public:
    explicit RicercaAvanzataWidget(Client*, QWidget* parent=0);

private:
    QGroupBox* initialBox;
    QVBoxLayout* layout;
    QFormLayout* inputForm;

    Client* logic;

    QLabel* titoloWidget;

    QLineEdit* titoloEdit;
    QLineEdit* linguaEdit;
    QLineEdit* editoreEdit;
    QLineEdit* collanaEdit;
    QLineEdit* autoreEdit;
    QLineEdit* genereEdit;
    QLineEdit* curatoreEdit;
    QLineEdit* traduttoreEdit;
    QLineEdit* lingua_originaleEdit;

    // pulsanti
    QRadioButton* completatoTrue;
    QRadioButton* completatoFalse;

    QPushButton* cerca;
    QPushButton* reset;

    void initializeCommonView();

public slots:
    void libroViewSlot();
    void bookViewSlot();
    void lightNovelViewSlot();
    void cercaLibroSlot();
    void cercaBookSlot();
    void cercaLightNovelSlot();
    void resetLibroSlot();
    void resetBookSlot();
    void resetLightNovelSlot();
};

#endif // RICERCAAVANZATAWIDGET_H
