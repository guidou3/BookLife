#ifndef LIGHTNOVELWIDGET_H
#define LIGHTNOVELWIDGET_H

#include "capitolowidget.h"
#include "Controller/client.h"

#include <QBoxLayout>
#include <QPushButton>
#include <QRadioButton>
#include <QLabel>
#include <QFormLayout>
#include <QListWidget>
#include <QGroupBox>
#include <QLineEdit>
#include <QDateEdit>
#include <QWidget>
#include <QPixmap>
#include <QDesktopServices>
#include <QUrl>
#include <QFileDialog>
#include <QScrollArea>

class LightNovelWidget : public QWidget
{
    Q_OBJECT

public:
    explicit LightNovelWidget(Light_novel*, Client*, QWidget *parent = 0);
    explicit LightNovelWidget(Client*, Light_novel*, QWidget *parent = 0);
    explicit LightNovelWidget(Client*, QWidget *parent = 0);
    ~LightNovelWidget();

private:
    // campi dati logici
    Client* logic;
    Light_novel* lightNovel;
    bool mine;
    int index;
    Capitolo* cap;


    // layout e box
    QVBoxLayout* mainLayout;
    QHBoxLayout* centralLayout;
    QGroupBox* visualizzaBox;
    QVBoxLayout* layCap;

    QLabel* titoloSchedaLabel;

    // campi grafici di visualizzazione
    QLabel* titoloLabel;
    QListWidget* autoriList;
    QLabel* dataPubblicazioneLabel;
    QLabel* linguaLabel;
    QListWidget* generiList;
    QLabel* descrizioneLabel;
    QLabel* fileImmagine;
    QLabel* immagineLabel;
    QLabel* capitoli_tradottiLabel;
    QLabel* capitoli_scrittiLabel;
    QLabel* completatoLabel;
    QListWidget* traduttoriList;
    QLabel* lingua_originaleLabel;
    QListWidget* capitoliList;

    QListWidgetItem* element;

    // campi grafici per l'inserimento/modifica dei dati
    QLineEdit* titoloEdit;
    QDateEdit* dataPubblicazioneEdit;
    QLineEdit* linguaEdit;
    QLineEdit* descrizioneEdit;
    QLineEdit* capitoli_tradottiEdit;
    QLineEdit* capitoli_scrittiEdit;
    QLineEdit* lingua_originaleEdit;
    QLineEdit* autoreEdit;
    QLineEdit* genereEdit;
    QLineEdit* traduttoreEdit;

    // pulsanti
    QRadioButton* completatoTrue;
    QRadioButton* completatoFalse;

    QPushButton* addAutore;
    QPushButton* removeAutore;
    QPushButton* addGenere;
    QPushButton* removeGenere;
    QPushButton* addTraduttore;
    QPushButton* removeTraduttore;

    QPushButton* addCapitolo;
    QPushButton* changeCapitolo;
    QPushButton* visualizzaCapitolo;

    QPushButton* annulla;
    QPushButton* salva;

    // metodi di classe privati
    void hide(); // metodo per nascondere i widget che normalmente dovrebbero essere nascosti (modifica + inserimento)
    void hideVisualize(); // metodo per nascondere i widget che normalmente dovrebbero essere nascosti (visualizzazione)
    void initialize();
    void capitoliListInitialize(); // inizializzazione lista dei capitoli

signals:
    void updateLightNovel();

public slots:
    void salvaSlot(); // procedura per il salvataggio di una nuova light novel nel database
    void aggiornaSlot(); // procedura per l'update dei dati di una light novel nel database
    void getAutoreSlot(); // procedura per il selezionamento di un item dalla lista autori e visualizzazione del pulsante di rimozione
    void getGenereSlot(); // procedura per il selezionamento di un item dalla lista generi e visualizzazione del pulsante di rimozione
    void getTraduttoreSlot(); // procedura per il selezionamento di un item dalla lista traduttori e visualizzazione del pulsante di rimozione
    void getCapitoloSlot(); // procedura per il selezionamento di un item dalla lista dei capitoli e visualizzazione dei relativi pulsanti
    void aggiungiAutoreSlot(); // procedura per l'inserimento di una nuova voce nella lista autori
    void rimuoviAutoreSlot(); // procedura per la rimozione di una nuova voce dalla lista autori
    void aggiungiGenereSlot(); // procedura per l'inserimento di una nuova voce nella lista generi
    void rimuoviGenereSlot(); // procedura per la rimozione di una nuova voce dalla lista generi
    void aggiungiTraduttoreSlot(); // procedura per l'inserimento di una nuova voce nella lista traduttori
    void rimuoviTraduttoreSlot(); // procedura per la rimozione di una nuova voce dalla lista traduttori
    void aggiungiCapitoloSlot(); // procedura per l'inserimento di un nuovo capitolo nella light novel, e corrispondente update della lista
    void modificaCapitoloSlot(); // procedura per l'update di un nuovo capitolo della light novel, e corrispondente update della lista
    void visualizzaCapitoloSlot(); // procedura per la visualizzazione del widget con il compito di mostrare il capitolo
    void visualizzaCapitoloCorrenteSlot(); // procedura per la visualizzazione del widget con il compito di mostrare il capitolo (versione che non necessità del getCapitolo(), dipende dal tipo di account)
    void updateListaCapitoliSlot(); // procedura per l'update della lista dei capitoli
    void apriImmagine(); // procedura per il selezionamento di un file immagine (.jpg o .png) dai file presenti nella macchina
};

#endif // LIGHTNOVELWIDGET_H
