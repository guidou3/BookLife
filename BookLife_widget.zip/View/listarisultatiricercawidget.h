#ifndef LISTARISULTATIRICERCAWIDGET_H
#define LISTARISULTATIRICERCAWIDGET_H

#include "listawidget.h"
#include "lightnovelwidget.h"
#include "bookwidget.h"

class ListaRisultatiRicercaWidget  : public ListaWidget
{
    Q_OBJECT

public:
    explicit ListaRisultatiRicercaWidget(Client*, QStringList, QWidget *parent = 0);

private:
    BookWidget* bw;
    LightNovelWidget* lnw;

    QVBoxLayout* risultato;

    void clean();

public slots:
    void getSlot();
    void hideSlot();

};

#endif // LISTARISULTATIRICERCAWIDGET_H
