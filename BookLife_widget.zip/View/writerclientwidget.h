#ifndef WRITERCLIENTWIDGET_H
#define WRITERCLIENTWIDGET_H

#include "clientwidget.h"
#include "listalavoriwidget.h"

#include <QWidget>


class WriterClientWidget : public ClientWidget
{
    Q_OBJECT

public:
    explicit WriterClientWidget(Session*, QWidget *parent = 0);
    ~WriterClientWidget();

private:
    // campi dati grafici
    ListaLavoriWidget* lavori;

    QPushButton* normalAccountButton; // pulsante per passare al client utente

signals:
    void normalAccount();

public slots:
    void checkSlot();
    void hideSlot();
};

#endif // WRITERCLIENTWIDGET_H
