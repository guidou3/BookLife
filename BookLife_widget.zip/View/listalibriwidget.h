#ifndef LISTALIBRIWIDGET_H
#define LISTALIBRIWIDGET_H

#include "listawidget.h"
#include "lightnovelwidget.h"
#include "bookwidget.h"

class ListaLibriWidget: public ListaWidget
{
    Q_OBJECT

public:
    explicit ListaLibriWidget(Client*, QString, bool, QWidget *parent = 0);

private:
    QString type;
    bool admin;

    QPushButton* visualizza;
    QPushButton* modifica;
    QPushButton* rimuovi;
    QPushButton* aggiungi;


signals:
    void updatePreferiti();

public slots:
    void getSlot();
    void updateSlot();
    void visualizzaSlot();
    void rimuoviSlot();
    void aggiungiSlot();
    void aggiungiPreferitoSlot();
    void modificaSlot();
    void hideSlot();

};

#endif // LISTALIBRIWIDGET_H
