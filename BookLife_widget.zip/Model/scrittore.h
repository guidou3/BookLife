#ifndef SCRITTORE_H
#define SCRITTORE_H

#include "Utente.h"
#include "amministratore.h"

class Scrittore : public Utente
{
private:
    QStringList lavori;
public:
    Scrittore(QString, QString, QList<QString> = QList<QString>(), QStringList  = QStringList());
    bool isMine(Light_novel*) const;
    void setMine(Light_novel*, bool);
    QStringList getLavori() const;
    void addLavoro(QString);
    void removeLavoro(QString);
    void setLavori(QStringList);

    virtual int tipoAccount() const;
};

#endif // SCRITTORE_H
